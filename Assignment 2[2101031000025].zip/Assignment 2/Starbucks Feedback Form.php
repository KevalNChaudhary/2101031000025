<!DOCTYPE html>
<html>

<head>
    <title>Starbucks Feedback Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url("anthony-rosset--cNAI6_U8E0-unsplash.jpg");
            /* Replace "background_image.jpg" with your actual image file path */
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            text-align: center;
            margin: 50px;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.8);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-top: 0;
        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        textarea {
            height: 100px;
        }

        .form-row {
            margin-bottom: 15px;
        }

        .form-row:last-child {
            margin-bottom: 0;
        }

        .form-row::after {
            content: "";
            display: table;
            clear: both;
        }

        .form-row label {
            float: left;
            width: 30%;
        }

        .form-row input,
        .form-row textarea {
            float: right;
            width: 70%;
        }

        .form-buttons {
            margin-top: 20px;
            text-align: center;
        }

        .form-buttons button {
            background-color: #00704a;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }

        .form-buttons button:last-child {
            margin-right: 0;
        }

        .message {
            margin-top: 20px;
            text-align: center;
        }

        .rating {
            display: flex;
            justify-content: center;
            margin-top: 10px;
        }

        .rating button {
            cursor: pointer;
            width: 30px;
            height: 30px;
            background-color: #ccc;
            border-radius: 50%;
            margin: 0 5px;
            border: none;
        }

        .rating button:hover,
        .rating button.selected {
            background-color: orange;
        }
    </style>
    <script>
        function validateForm() {
            var name = document.getElementById('name').value;
            var email = document.getElementById('email').value;
            var feedback = document.getElementById('feedback').value;

            if (name === '' || email === '' || feedback === '') {
                alert('Please fill in all the fields.');
                return false;
            }

            return true;
        }

        function selectRating(rating) {
            var buttons = document.querySelectorAll('.rating button');

            for (var i = 0; i < buttons.length; i++) {
                if (i < rating) {
                    buttons[i].classList.add('selected');
                } else {
                    buttons[i].classList.add('selected');
                }
            }

            document.getElementById('selectedRating').value = rating;
        }
    </script>
</head>

<body>
    <div class="container">
        <div class="logo">
            <img src="Logo.jpg" alt="Starbucks Logo" width="150" height="100">
        </div>
        <h2>Starbucks Feedback Form</h2>

        <?php
        if (isset($_POST['submit'])) {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $feedback = $_POST['feedback'];

            if (empty($name) || empty($email) || empty($contact) || empty($feedback)) {
                echo '<p class="message">Please fill in all the fields.</p>';
            } else {
                echo '<p class="message">Thank you for your feedback!</p>';
            }
        }
        ?>

        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" onsubmit="return validateForm()">
            <div class="form-row">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-row">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-row">
                <label for="contact">Contact No:</label>
                <input type="tel" id="contact" name="contact" required>
            </div>

            <div class="form-row">
                <label for="feedback">Feedback:</label>
                <textarea id="feedback" name="feedback" required></textarea>
            </div>

            <div class="form-row">
                <label for="rating">Rating:</label>
                <div class="rating">
                    <button onclick="selectRating(1)"></button>
                    <button onclick="selectRating(2)"></button>
                    <button onclick="selectRating(3)"></button>
                    <button onclick="selectRating(4)"></button>
                    <button onclick="selectRating(5)"></button>
                </div>
            </div>

            <input type="hidden" id="selectedRating" name="selectedRating" value="">

            <div class="form-buttons">
                <button type="submit" name="submit">Submit</button>
                <button type="reset">Reset</button>
            </div>
        </form>
    </div>
</body>

</html>
