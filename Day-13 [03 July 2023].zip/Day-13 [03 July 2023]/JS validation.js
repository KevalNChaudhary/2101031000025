function Name()
{

    var F=document.getElementById("Name").value;
    if(F=="" || F==null)
    {
        alert("First Name Is Required...");
       // return false;
    }


    var i=document.getElementById("Email").value;
    if(F=="" || F==null)
    {
        alert("Email Is Required...");
       // return false;
    }

    var F=document.getElementById("Contact").value;
    if(F=="" || F==null)
    {
        alert("Contact Is Required...");
       return false;
    }
     
    alert("Form Submited Succesfully");

}