<?php

    // Area Of Circle
    $r = 7;
    $pi = 3.14;
    $a = $pi*$r*$r;
    echo "Area of circle with radius ", $r , " is : " , $a;
    echo "<br>";

    //Area Of Rectangle
    $l = 25;
    $b = 11;
    $ar = $l * $b;
    echo "Area of rectangle with side ", $l , " & " , $b , " is : " , $ar;
?>