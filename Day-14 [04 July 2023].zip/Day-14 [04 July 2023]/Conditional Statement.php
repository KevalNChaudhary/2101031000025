<?php
// If Statement

$time = date("Hour");

if ($time < "25") {
  echo "Have a good day!";
  echo $time;
  echo "<br>";
}


// If Else Statement
function largest($a, $b, $c) {
    $max = $a;
    if ($a >= $b) {
      if($a >= $c) 
        $max = $a;
      else
        $max = $c;
    }
    else {
      if($b >= $c) 
        $max = $b;
      else
        $max = $c;
    }
    
    echo "Largest number among $a, $b and $c is: $max\n";
    echo $max;
 echo "<br>";
  }
  
  largest(25,11,04);
  largest(01,03,04);



// If Else If Statement
$marks=95;      
if ($marks<33){    
    echo "fail";    
}    
else if ($marks>=34 && $marks<50) {    
    echo "D grade";    
}    
else if ($marks>=50 && $marks<65) {    
   echo "C grade";   
}    
else if ($marks>=65 && $marks<80) {    
    echo "B grade";   
}    
else if ($marks>=80 && $marks<90) {    
    echo "A grade";    
}  
else if ($marks>=90 && $marks<100) {    
    echo "A+ grade";   
}  
else {    
    echo "Invalid input";    
} 


// Switch Case

   echo "<br>";

$a = 1;
switch ($a) {
    case 1:
        printf("Choice is 1");
        break;
    case 2:
        printf("Choice is 2");
        break;
    case 3:
        printf("Choice is 3");
        break;
    default:
        printf("Choice other than 1, 2 and 3");
        
}
?>