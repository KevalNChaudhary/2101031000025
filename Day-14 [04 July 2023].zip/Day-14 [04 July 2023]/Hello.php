<?php
echo"Hello World From Php";
?>