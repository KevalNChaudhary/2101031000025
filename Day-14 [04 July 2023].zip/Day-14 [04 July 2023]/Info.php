<?php
 $name = "Keval N Chaudhary";
 $dept = "Information Technology";
 $enroll = 2101031000025;
 $College = "Silver Oak University";

 echo $name;
 echo "<br>";
 echo $dept;
 echo "<br>";
 echo $enroll;
 echo "<br>";
 echo $College;
 echo "<br>";

?>