<?php

// While Loop
echo "while loop";
echo "<br>";
$x = 1;

while($x <= 7) {
  echo "The number is: $x <br>";
  $x++;
}

// Do While Loop
echo "<br>";
echo "<br>";
echo "<br>";
echo "do while loop";
echo "<br>";
$x = 1;

do {
  echo "The number is: $x <br>";
  $x++;
} while ($x <= 7);


// For Loop
echo "<br>";
echo "<br>";
echo "<br>";
echo "for loop";
echo "<br>";
for ($x = 0; $x <= 7; $x++) {
    echo "The number is: $x <br>";
  }

  // For Each Loop
  echo "<br>";
  echo "<br>";
  echo "<br>";
  echo "for each loop";
  echo "<br>";
  $name = array("Keval", "Ankur", "Siddh", "Meghav","Param");

foreach ($name as $value) {
  echo "$value <br>";
}


?>