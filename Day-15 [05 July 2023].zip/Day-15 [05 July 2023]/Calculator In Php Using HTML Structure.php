<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
</head>
<body>
<?php
$FirstNumber = 25;
$SecondNumber = 1;
$operator = 1;

switch ($operator) {
case 1:
echo ($FirstNumber + $SecondNumber);
break;
case 2:
 echo  ($FirstNumber - $SecondNumber);
break;
case 3:
echo ( $FirstNumber * $SecondNumber);
break;
case 4:
echo ( $FirstNumber / $SecondNumber);
}

?> 
</body>
</html>