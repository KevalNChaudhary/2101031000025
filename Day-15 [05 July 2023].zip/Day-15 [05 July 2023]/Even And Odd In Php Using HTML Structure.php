<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Even And Odd Number</title>
</head>
<body>
    <?php
     $n=04;
    
     if($n%2==0)
     {
         echo $n." is Even Number";
     }
     else{
         
         echo $n." is odd Number";
     }
 
    ?>
</body>
</html>