<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>For & While Loop</title>
</head>
<body>
    <?php
for ($x = 1; $x <= 10; $x++) {           // For Loop
    echo "The number is: $x <br>";
  }



echo "<br>"; 
echo "<br>";
$x = 1;     // While Loop
while($x<=10) {
    echo $x*2;
     echo "<br>";
     $x++;

  }
  ?>

</body>
</html>