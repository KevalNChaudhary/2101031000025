<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    echo "<br>";     // Operators 
    $a = 11;
    $b = 15;
    echo "Value of a is : " , $a;
    echo "<br>";
    echo "Value of b is : " , $b;
    echo "<br>";
    echo "Addition is : " , $a+$b;
    echo "<br>";
    echo "Subtraction is : " , $a-$b;
    echo "<br>";
    echo "Multiplication is : " , $a*$b;
    echo "<br>";
    echo "Divition is : " , $a/$b;
    echo "<br>";
    ?>

</body>
</html>