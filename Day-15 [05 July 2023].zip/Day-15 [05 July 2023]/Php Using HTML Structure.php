<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Php Using HTML Structure</title>
</head>
<body>
    
<?php
echo "Hello Everyone !"."<br>";    //Print Using echo
echo "How Are You ?"."<br>";

echo "<br>";           // br uesd for print new line after or below perticular line.
print "Hello !"."<br>"; //Print Using print
print "How Are You ?";

echo "<br>";    //Print value
echo "<br>";
$a=10;
echo "Value Of a is:",$a;


echo "<br>";     // Operators 
$a = 11;
$b = 15;
echo "Value of a is : " , $a;
echo "<br>";
echo "Value of b is : " , $b;
echo "<br>";
echo "Addition is : " , $a+$b;
echo "<br>";
echo "Subtraction is : " , $a-$b;
echo "<br>";
echo "Multiplication is : " , $a*$b;
echo "<br>";
echo "Divition is : " , $a/$b;
echo "<br>";

echo "<br>";
$a = "123abc";
echo "Type Of a is:".gettype($a); // gettype used for identify or get the data type of data

echo "<br>";    
echo "<br>";
settype($a,"int");   // settype used for set type of data
echo "After Conversion Type Of a is:".gettype($a);

echo "<br>";
echo "<br>";
$a = 25;      // Comaparision Operators
$b = 11;
echo ($a>$b)?($a."Is Greater"):($b."Is Greater");

echo "<br>"; 
echo "<br>";
$a = 25;     // If-Else Statement
$b = 11;
if($a > $b)
{
    echo "a is graeter";
}
else{
    echo "b is graeter";  
}

echo "<br>"; 
echo "<br>";
$a = 25;       //Nested If Else Loop
$b = 11; 
$c = 07; 
if($a>=$b)
{
    if($a>=$c)
    {
        echo "a is Greater";
    }
    else{
        echo "c is Greater";
    }
}
else
{
    if($a>=$c){
    echo "a is Greater";}

    else{
    echo "c is Greater";}
}


echo "<br>";
echo "<br>";  // For Loop
for ($x = 1; $x <= 10; $x++) {
    echo "The number is: $x <br>";
  }



echo "<br>"; 
echo "<br>";
$x = 1;     // While Loop
while($x<=10) {
    echo $x*2;
     echo "<br>";
     $x++;

  }

  // Min 8 Demos [2,4,5,6,7]
    //  control Structure
    //  Loop Structure

?>


</body>
</html>
