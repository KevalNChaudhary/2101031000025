<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statement</title>
</head>
<body>
    <?php
$a = 25;     // If-Else Statement
$b = 11;
if($a > $b)
{
    echo "a is graeter";
}
else{
    echo "b is graeter";  
}

echo "<br>"; 
echo "<br>";
$a = 25;       //Nested If Else Statement
$b = 11; 
$c = 07; 
if($a>=$b)
{
    if($a>=$c)
    {
        echo "a is Greater";
    }
    else{
        echo "c is Greater";
    }
}
else
{
    if($a>=$c){
    echo "a is Greater";}

    else{
    echo "c is Greater";}
}
?>
</body>
</html>