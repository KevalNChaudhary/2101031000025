<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loop Structure</title>
</head>
<body>
    <?php
        $x = 0;               // While Loop Example
        while($x <= 100) {
          echo "The number is: $x <br>";
          $x+=10;
        }

        echo "<br>";
        echo "<br>";   // While Loop Example
        $i = 0;
        while ($i < 5){
        echo $i + 1 . "<br>";
        $i++;


        echo "<br>";
        echo "<br>";  // Do While Loop
        $x = 1;
        do {
        echo "The number is: $x <br>";
        $x++;
        } while ($x <= 5);  

}


    echo "<br>";   // Do While Loop 
    echo "<br>";
    $x = 5;  
    do {  
        echo "Silver Oak University! </br>";  
        $x++;  
    } while ($x < 10);  


    echo "<br>";    // For Loop 
    echo "<br>";
    for ($x = 1; $x <= 10; $x++) {
        echo "The number is: $x <br>";
      }

      echo "<br>";    // For Loop 
      echo "<br>";
      for( $num = 0; $num < 20; $num += 5) {
        echo $num . "\n";
    }


    echo "<br>";   // For Each Loop
    echo "<br>";
    $age = array("Jaival"=>"45", "Karan"=>"40", "Harsh"=>"43");

    foreach($age as $x => $val) {
    echo "$x = $val<br>";
}

echo "<br>";   // For Each Loop
echo "<br>";
$student = array( 
    "Name" => "Keval N Chaudhary", 
    "Email" => "chaudharykeval07@gmail.com", 
    "Age" => 19, 
    "Gender" => "Male"
  );  
foreach($student as $key => $element) { 
    echo $key . ": " . $element . "<br>"; 
} 


echo "<br>";   // Break
echo "<br>";
for ($x = 0; $x < 10; $x++) {
    if ($x == 4) {
      break;
    }
    echo "The number is: $x <br>";
  }


  echo "<br>";      // Break
  echo "<br>";
  $array = array('A', 'B', 'C', 'D', 'E', 'F');
foreach ($array as $let) {
if ($let == 'E') {
break;
}
echo "$let \n";
}


  echo "<br>";   // Continue
  echo "<br>";
  for ($x = 0; $x < 10; $x++) {
    if ($x == 4) {
      continue;
    }
    echo "The number is: $x <br>";
  }


  echo "<br>";      // Continue
  echo "<br>";
  $array = array('A', 'B', 'C', 'D', 'E', 'F');
foreach ($array as $let) {
if ($let == 'E') {
 continue;
}
echo "$let \n";
}

    ?>
</body>
</html>