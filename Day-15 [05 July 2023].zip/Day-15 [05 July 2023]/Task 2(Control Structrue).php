<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control Structure</title>
</head>
<body>
    <?php      
    
    $x=1;          // If Statement
    if ($x == 1) 
     echo "$x is Equal to 1";

     echo "<br>";     // If statement
     echo "<br>";
     if ($x == 1) {
        echo "$x is Equal to 1";
        $x++;
        echo "<br>";
        echo "Now $x is Equal to 2";
     }

     
     echo "<br>";      // Else Staement
     echo "<br>";
     $a=1;
    if ($a == 2) {
    echo "$a is equal to 2";
    } else {
    echo "$a is equal to 1";
    }

    echo "<br>";      // Else Staement
    echo "<br>";
    $age=19;
   if ($age <= 18) {
   echo "$age is not Eligible For Voting";
   } else {
   echo "$age is Eligible For Voting";
   }


   echo "<br>";   // Else If Statement
   echo "<br>";
   if ($x == 2) {
    echo "$x is equal to 2";
    } else if ($x == 1) {
    echo "$x is equal to 1";
    } else {
       echo "$x does not equal 2 or 1";
    }


    echo "<br>";   // Else If Statement
    echo "<br>";
    $time = date("Hour");
    echo "<p>The hour (of the server) is " . $time; 
    echo ", and will give the following message:</p>";
     if ($time < "10") {
      echo "Have a good morning!";
    } elseif ($time < "20") {
      echo "Have a good day!";
    } else {
      echo "Have a good night!";
    }


    echo "<br>";   // Switch Statement
    echo "<br>";
    $c= "White";
    switch ($c) {
  case "Green":
    echo "Your Favorite Color is Green!";
    break;
  case "Blue":
    echo "Your Favorite Color is Blue!";
    break;
  case "Grey":
    echo "Your Favorite Color is Grey!";
    break;
  default:
    echo "Your Favorite Color is Neither Red, Blue, Nor Green!";
}


echo "<br>";   // Switch Statement
echo "<br>";
$a= "25";
switch ($a) {
case "11":
echo "Your Number is 11!";
break;
case "27":
echo "Your Number is 04!";
break;
case "25":
echo "Your Number is 25!";
break;
default:
echo "Your Number is Neither 11, 04, Nor 25!";
}


echo "<br>";  // Nested If Else Statement
echo "<br>";
$a = 25; 
$b = 11;
$c = 04;

if ($a>$b)
{
     if ($a>$c)
   {
      echo "A Value Is Bigger";
   }
     else
   {
      echo "C Value Is Bigger";
   }
}
else 
{
  if ($b>$c)
   {
      echo "B Value Is Bigger";
   }
     else
   {
      echo "C Value Is Bigger";
   }
}


    ?>

</body>
</html>