<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Index</title>
</head>
<body>
    
    <?php
    echo "<br>";  // Array Indexing
    echo "<br>";
    $a = array("xyz"=>12,"Abc"=>22,"jkl"=>18); 
    print_r($a);
    ?>

</body>
</html>