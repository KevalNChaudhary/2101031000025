<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mathemetical Functions</title>
</head>
<body>
    
<?php
 $a = 106;    // pw =power , abs =absulute , min =minium
 echo abs($a);
 echo "<br>";
 echo pow(2,3);
 echo "<br>";
 echo min(1,2,3,4,5,6,7); 
 echo "<br>";
 $b = 616.996;
 echo ceil($b);
?>

</body>
</html>