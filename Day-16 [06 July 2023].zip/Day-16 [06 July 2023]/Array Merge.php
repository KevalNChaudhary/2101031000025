<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Merge Array</title>
</head>
<body>
    <?php
        $arr_1 = array(1,2,3,4,5,6,7);
        $arr_2 = array(6,7,10,8,9,);
        print_r($arr_1);
        echo "<br>";
        print_r($arr_2);
        echo "<br>";
        $merge = array_merge($arr_1,$arr_2);
        print_r($merge);
    ?>

</body>
</html>