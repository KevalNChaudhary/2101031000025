<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array String Reverse & Count</title>
</head>
<body>
    
    <?php
        // Array String Reverse
        $a = array("Keval","Ankur","Jaival","Murtuza","Karan","Harsh"); 
        print_r($a);
        echo "<br>";
        $a = array_reverse($a);
        print_r($a);
        echo "<br>";
        echo count($a);  // Used To Count Elements In The Array
    ?>

</body>
</html>