<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Things</title>
</head>
<body>
    
<?php
        $a = "Silver Oak University";    //Array Str Upper,Lower,Replace,asking value(ord),len
        echo $a;
        echo "<br>";
        echo strlen($a);
        echo "<br>";
        echo strtoupper($a);
        echo "<br>";
        echo strtolower($a);
        echo "<br>";
        echo ord($a);
        echo "<br>";
        echo str_replace("S","A",$a);
        echo "<br>";
?>

</body>
</html>