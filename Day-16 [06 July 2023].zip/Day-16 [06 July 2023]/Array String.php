<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sorting Array</title>
</head>
<body>

    <?php
          // Array String Sorting
    
        $a = array("Keval","Ankur","Jaival","Murtuza","Karan","Harsh"); 
        print_r($a);
        sort($a);
        echo "<br>";
        echo "After Sorting Array";
        print_r($a);
        ?>

</body>
</html>