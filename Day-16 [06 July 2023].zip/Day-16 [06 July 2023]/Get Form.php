<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="get.php" id="from1" name="form" method="get">
        Username : 
        <input type="text"   name="username" id="username"><br><br>
        Password : 
        <input type="text"  name="password" id="password"><br><br>
        <input type="submit" name="submit" id="submit">
    </form>
</body>
</html>