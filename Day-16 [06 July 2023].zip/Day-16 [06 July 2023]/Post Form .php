<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="post.php" id="from1" name="form" method="post">
    Username : <input type="text"  id="username" name="username"><br><br>
    Password : <input type="text" id="password" name="password"><br><br>
    <input type="submit" name="submit" id="submit">
</form>
</body>
</html>