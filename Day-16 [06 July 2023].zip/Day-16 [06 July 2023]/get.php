<?php
$username = $_GET['username'];    //Used To get data of GetForm which is created in it. 
$password = $_GET['password'];
echo $username;                  // Here name mater more than id.
echo "<br>";
echo $password;        // Show Password in Url So (unsecure Method)
?>