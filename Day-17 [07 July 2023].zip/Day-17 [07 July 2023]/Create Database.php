<?php
    $username = "root";
    $servername = "localhost";
    $password = "";
    $conn = mysqli_connect($servername,$username,$password); 
    // if(!$conn)
    // {
    //     die ("Connection Failed".mysqli_connect_arr());    //  die used for Print or checked Connection Error  
    // }  

     $sql = "create database b";   // Always Change name to create anothor  it cann't run second time because DB created once only. 
     if(mysqli_query($conn,$sql))
    {
         echo "database created";
     }
     else{
         echo "error";
     }
    
?>