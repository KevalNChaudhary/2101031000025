<?php
    $username = "root";
    $servername = "localhost";
    $password = "";
    $dbname = "b";
    $conn = mysqli_connect($servername,$username,$password,$dbname);

    if(! $conn){
        die("Connection failed".mysqli_connect_error());
    }

    $sql  = "INSERT INTO info(username,password) VALUES('Keval','Keval2004'),('Ankur','Ankur2004'),('Meghav','Meghav2004'),('Param','Param2004'),('Siddh','Siddh2004')";
    if(mysqli_query($conn,$sql)){
            echo "Data inserted";
        }
        else{
            echo "error";
    }
?>


<!-- please do file name .html and save so Output image link can be open -->
<img src="Screenshot (30).png";