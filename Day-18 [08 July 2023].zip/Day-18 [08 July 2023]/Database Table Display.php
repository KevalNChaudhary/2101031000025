<?php
$username = "root";
$servername = "localhost";
$password = "";
$dbname = "a";
 
$conn = mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die("connection failed".mysqli_connect_error());
}
else
{
    echo "Connected Successfully";
}

echo "<br>";
echo "<br>";
$sql = "select * from abc";
$result = mysqli_query($conn,$sql);
print_r($result);

echo "<br>";
echo "<br>";
$res1 = mysqli_num_rows($result);
if ($res1 > 0) {
    echo '<table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact No</th>
                    <th>Email Id</th>
                </tr>
            </thead>
            <tbody>';
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>
                <td>' . $row["Id"] . '</td>
                <td>' . $row["First Name"] . '</td>
                <td>' . $row["Last Name"] . '</td>
                <td>' . $row["Contact No"] . '</td>
                <td>' . $row["Email Id"] . '</td>
              </tr>';
    }
    echo '</tbody>
        </table>';
} else {
    echo "No records found.";
}

                                     // Below Thing Is used to print particular things like Id,First Name and etc. 

// $res1 = mysqli_num_rows($result);
// if ($res1 > 0) {
//     echo '<table style="border-collapse: collapse; border: 1px solid black; padding: 10px; background-color:lightgreen;">
//             <tr>
//                 <th style="border: 1px solid black; padding: 10px; background-color:darkseagreen;">ID</th>
//                 <th style="border: 1px solid black; padding: 10px; background-color:darkseagreen;">First Name</th>
//                 <th style="border: 1px solid black; padding: 10px; background-color:darkseagreen;">Last Name</th>
//                 <th style="border: 1px solid black; padding: 10px; background-color:darkseagreen;">Contact</th>
//                 <th style="border: 1px solid black; padding: 10px; background-color:darkseagreen;">Email</th>
//             </tr>';
//     while ($row = mysqli_fetch_assoc($result)) {
//         echo '<tr>
//                 <td style="border: 1px solid black; padding: 10px;">' . $row["id"] . '</td>
//                 <td style="border: 1px solid black; padding: 10px;">' . $row["FIrstName"] . '</td>
//                 <td style="border: 1px solid black; padding: 10px;">' . $row["LastName"] . '</td>
//                 <td style="border: 1px solid black; padding: 10px;">' . $row["Contact"] . '</td>
//                 <td style="border: 1px solid black; padding: 10px;">' . $row["Email"] . '</td>
//               </tr>';
//     }
//     echo '</table>';
// } else {
//     echo "No records found.";
// }


?>

<!-- please do file name .html and save so Output image link can be open
<img src="Screenshot (31).png";

<img src="Screenshot (32).png"; -->