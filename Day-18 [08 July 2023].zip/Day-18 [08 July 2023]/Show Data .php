<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Data Of Table</title>
</head>
<body>
    <?php
    $username="root";
    $servername="Localhost";
    $password="";
    $DB="a";
    $con=mysqli_connect($servername,$username,$password,$DB);
    if(!$con){
        die("Connection Failed".mysqli_connect_error());
    }

    $sql="select * from Abc"; 
    $result=mysqli_query($con,$sql);
    $res1 = mysqli_num_rows($result);
    if($res1>0)
    {
        while($row = mysqli_fetch_assoc($result)){
            echo "ID =".$row["Id"]."<br>"."Firstname=".$row["First Name"]."<br>"."Lastname=".$row["Last Name"]."<br>";
            
        }

    }
    else
    {
        echo "No Records";
    }
    ?>
</body>
</html>