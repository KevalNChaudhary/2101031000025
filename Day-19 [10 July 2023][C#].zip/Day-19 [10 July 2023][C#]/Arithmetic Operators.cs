﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arithmetic_Operators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 25;
            int y = 11;
            Console.WriteLine(x + y);
            Console.WriteLine(x - y);
            Console.WriteLine(x * y);
            Console.WriteLine(x / y);
            Console.WriteLine(x % y);
            Console.WriteLine(++x);
            Console.WriteLine(--x);


        }
    }
}
