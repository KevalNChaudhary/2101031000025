﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_Name_Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Giving one message to the user to enter his name
            Console.WriteLine("Enter Your Name");

            //ReadLine method reads a string value from the keyboard 
            string name = Console.ReadLine();

            //Printing the entered string in the console
            Console.WriteLine($"Hello {name}");
            Console.ReadKey();

        }
    }
}
