﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_Value_Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //We can access WriteLine and Write method using class name
            //as these methods are static

            //WriteLine Method Print the value and move the cursor to the next line
            Console.WriteLine("Hey");
            //Write Method Print the value and stay in the same line
            Console.Write("HI ");
            //Write Method Print the value and stay in the same line
            Console.Write("Everyone");
            //WriteLine Method Print the value and move the cursor to the next line
            Console.WriteLine("Good Morning");
            //Write Method Print the value and stay in the same line
            Console.Write("From C#.NET ");
            Console.ReadKey();

        }
    }
}
