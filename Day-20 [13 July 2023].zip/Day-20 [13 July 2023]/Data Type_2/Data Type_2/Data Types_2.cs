﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Type_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int myNum = 25;               // integer (whole number)
            double myDoubleNum = 3.14D;  // floating point number
            char myLetter = 'A';         // character
            bool myBool = true;          // boolean
            string myText = "KEVAL CHAUDHARY";     // string
            Console.WriteLine(myNum);
            Console.WriteLine(myDoubleNum);
            Console.WriteLine(myLetter);
            Console.WriteLine(myBool);
            Console.WriteLine(myText);

        }
    }
}
