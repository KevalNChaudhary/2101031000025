﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operators_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x = 25;  // Comparision Operators.
            int y = 11;
            Console.WriteLine(x > y);
            Console.WriteLine(y > x);
            Console.WriteLine(x == y);
            Console.WriteLine(y >= x);
            Console.WriteLine(x <= y);
            Console.WriteLine(y != x);
        }
    }
}
