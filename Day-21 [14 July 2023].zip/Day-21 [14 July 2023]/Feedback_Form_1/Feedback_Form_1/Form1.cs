﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Feedback_Form_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text;
            string Surname = textBox2.Text;
            string Email = textBox3.Text;
            string Contact = textBox4.Text;
            string Feedback = textBox5.Text;

            label1.Text = Name;
            label2.Text = Surname;
            label3.Text = Email;
            label4.Text = Contact;
            label5.Text = Feedback;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Enter The Name Here...";
            textBox2.Text = "Enter The Surname Here...";
            textBox3.Text = "Enter The Email Here...";
            textBox4.Text = "Enter The Contact Here...";
            textBox5.Text = "Enter The Feedback Here...";

            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";

        }
    }
}
